import java.rmi.*;
public interface AddServerIntf extends Remote { 
//method declaration 
int fct(int d1) throws RemoteException;
}
