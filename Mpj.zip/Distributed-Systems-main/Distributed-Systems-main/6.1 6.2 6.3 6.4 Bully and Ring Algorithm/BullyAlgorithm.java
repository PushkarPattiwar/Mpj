import java.util.*;

public class BullyAlgorithm {
    int coordinator; // Current coordinator
    int maxProcesses; // Number of processes
    boolean[] processes; // Status of each process (up or down)

    // Constructor
    public BullyAlgorithm(int maxProcesses) {
        this.maxProcesses = maxProcesses;
        processes = new boolean[maxProcesses];
        coordinator = maxProcesses; // Default highest process as coordinator

        // Initialize all processes as "up"
        System.out.println("Creating processes...");
        for (int i = 0; i < maxProcesses; i++) {
            processes[i] = true;
            System.out.println("Process P" + (i + 1) + " created.");
        }
        System.out.println("Process P" + coordinator + " is the initial coordinator.");
    }

    // Display the status of all processes
    void displayProcesses() {
        System.out.println("Processes status:");
        for (int i = 0; i < maxProcesses; i++) {
            System.out.println("P" + (i + 1) + " is " + (processes[i] ? "up" : "down"));
        }
        System.out.println("Current coordinator: P" + coordinator);
    }

    // Bring a process up
    void upProcess(int processId) {
        if (processes[processId - 1]) {
            System.out.println("Process P" + processId + " is already up.");
        } else {
            processes[processId - 1] = true;
            System.out.println("Process P" + processId + " is now up.");
        }
    }

    // Bring a process down
    void downProcess(int processId) {
        if (!processes[processId - 1]) {
            System.out.println("Process P" + processId + " is already down.");
        } else {
            processes[processId - 1] = false;
            System.out.println("Process P" + processId + " is now down.");
        }
    }

    // Run the election algorithm
    void runElection(int processId) {
        if (!processes[processId - 1]) {
            System.out.println("Process P" + processId + " is down and cannot initiate an election.");
            return;
        }

        System.out.println("Process P" + processId + " has initiated an election.");

        int newCoordinator = processId; // Start with the initiator as the potential leader

        // Send election messages to higher-numbered processes
        for (int i = processId; i < maxProcesses; i++) {
            if (processes[i]) {
                System.out.println("Election message sent from P" + processId + " to P" + (i + 1));
                newCoordinator = i + 1; // Update the new coordinator to the highest active process
            }
        }
        // Declare the new coordinator
        coordinator = newCoordinator;
        System.out.println("Process P" + coordinator + " is elected as the new coordinator.");

        /*Announce the new coordinator to all processes
        for (int i = 0; i < maxProcesses; i++) {
            if (processes[i]) {
                System.out.println("Coordinator announcement sent to P" + (i + 1));
            }
        }*/
    }

    // Main method to test the algorithm
    public static void main(String[] args) {
        BullyAlgorithm bully = null;
        Scanner sc = new Scanner(System.in);

        while (true) {
            System.out.println("\nBully Algorithm");
            System.out.println("1. Create processes");
            System.out.println("2. Display processes");
            System.out.println("3. Bring a process up");
            System.out.println("4. Bring a process down");
            System.out.println("5. Run election algorithm");
            System.out.println("6. Exit");
            System.out.print("Enter your choice: ");
            int choice = sc.nextInt();

            switch (choice) {
                case 1:
                    System.out.print("Enter the number of processes: ");
                    int maxProcesses = sc.nextInt();
                    bully = new BullyAlgorithm(maxProcesses);
                    break;
                case 2:
                    if (bully != null)
                        bully.displayProcesses();
                    else
                        System.out.println("Please create processes first.");
                    break;
                case 3:
                    if (bully != null) {
                        System.out.print("Enter the process number to bring up: ");
                        int processId = sc.nextInt();
                        bully.upProcess(processId);
                    } else {
                        System.out.println("Please create processes first.");
                    }
                    break;
                case 4:
                    if (bully != null) {
                        System.out.print("Enter the process number to bring down: ");
                        int processId = sc.nextInt();
                        bully.downProcess(processId);
                    } else {
                        System.out.println("Please create processes first.");
                    }
                    break;
                case 5:
                    if (bully != null) {
                        System.out.print("Enter the process number to initiate election: ");
                        int processId = sc.nextInt();
                        bully.runElection(processId);
                    } else {
                        System.out.println("Please create processes first.");
                    }
                    break;
                case 6:
                    System.out.println("Exiting program.");
                    sc.close();
                    System.exit(0);
                    break;
                default:
                    System.out.println("Invalid choice. Please try again.");
            }
        }
    }
}
